﻿import os
import sys
import time

import requests

API_URL = os.getenv(
    "QUICKLINK_API_URL",
    "http://127.0.0.1:8000/shorten",
)

MAX_RETRIES = 3
BACKOFF_SECONDS = 0.5
FAILURE_THRESHOLD = 3
RECOVERY_SECONDS = 10
TIMEOUT_SECONDS = 2

failure_count = 0
circuit_opened_at = None


def circuit_allows_request():
    global circuit_opened_at

    if circuit_opened_at is None:
        return True

    if time.monotonic() - circuit_opened_at >= RECOVERY_SECONDS:
        print("Circuit breaker: allowing one recovery attempt")
        return True

    return False


def record_success():
    global failure_count, circuit_opened_at
    failure_count = 0
    circuit_opened_at = None
    print("Circuit breaker CLOSED: service recovered")


def record_failure():
    global failure_count, circuit_opened_at

    failure_count += 1
    print(f"Consecutive failed operations: {failure_count}")

    if failure_count >= FAILURE_THRESHOLD and circuit_opened_at is None:
        circuit_opened_at = time.monotonic()
        print("Circuit breaker OPEN: failure threshold reached")


def shorten(url, post=requests.post):
    if not circuit_allows_request():
        print("Request blocked: circuit breaker is OPEN")
        return None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = post(
                API_URL,
                json={"url": url},
                timeout=TIMEOUT_SECONDS,
            )

            if response.status_code >= 500:
                raise requests.HTTPError(
                    f"Server error: HTTP {response.status_code}"
                )

            response.raise_for_status()
            result = response.json()
            record_success()
            print("Success:", result)
            return result

        except requests.RequestException as exc:
            print(f"Attempt {attempt}/{MAX_RETRIES} failed: {exc}")

            if attempt < MAX_RETRIES:
                delay = BACKOFF_SECONDS * (2 ** (attempt - 1))
                print(f"Retrying in {delay:.1f} seconds...")
                time.sleep(delay)

    record_failure()
    return None


def simulated_failure(url, **kwargs):
    raise requests.ConnectionError("Simulated service outage")


class SimulatedSuccess:
    status_code = 200

    def raise_for_status(self):
        pass

    def json(self):
        return {"code": "DEMO42", "created": True}


def simulated_success(url, **kwargs):
    return SimulatedSuccess()


def demo():
    global RECOVERY_SECONDS

    # Keep the demonstration quick while leaving production settings intact.
    RECOVERY_SECONDS = 2

    print("=== Reliability demo (simulated; no server or database required) ===")
    for number in range(1, FAILURE_THRESHOLD + 1):
        print(f"\nOperation {number}: simulate an outage")
        shorten(f"https://example.com/failure-{number}", post=simulated_failure)

    print("\nAttempt while the circuit is open:")
    shorten("https://example.com/blocked", post=simulated_success)

    print(f"\nWaiting {RECOVERY_SECONDS} seconds for recovery...")
    time.sleep(RECOVERY_SECONDS + 0.1)

    print("\nRecovery attempt:")
    shorten("https://example.com/recovered", post=simulated_success)


if __name__ == "__main__":
    if "--demo" in sys.argv:
        demo()
    else:
        print("QuickLink caller: real API mode")
        shorten("https://example.com/caller-demo")
