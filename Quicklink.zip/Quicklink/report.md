﻿# QuickLink Assignment 2 — Technical Report

## 1. Overview

This assignment extends QuickLink with a documented REST API, duplicate-request handling, rate limiting, a client reliability demonstration, a gRPC service, and Prometheus/Grafana monitoring. The goal is to make API behavior more predictable for callers and make service behavior observable during normal and error cases.

## 2. REST constraints (Part A)

| Constraint | Meaning | Example from QuickLink |
|---|---|---|
| Client–server | UI/client and API stay separate | Browser or `caller.py` talks to FastAPI over HTTP |
| Stateless | Each request carries what the server needs | Every `POST /shorten` includes the URL; no server session |
| Cacheable | Responses may be marked cacheable or not | `GET /{code}` uses `307`; clients/proxies can decide caching |
| Uniform interface | Shared resources, methods, and representations | Resources via paths; JSON bodies; `201`/`200`/`400`/`429`/`404` |
| Layered system | Client need not know about intermediaries | Prometheus/Grafana sit beside the API without changing callers |
| Code on demand (optional) | Server may send executable code | Not demonstrated (optional; API returns data only) |

## 3. REST API contract and OpenAPI

OpenAPI is a machine-readable description of an HTTP API: paths, methods, request bodies, and success/error responses. Teams use it to document contracts, review behavior before coding clients, and drive interactive docs or client generators. Keeping the spec aligned with the live service reduces integration mistakes.

The specification is `openapi.yaml`. It matches `/shorten`, `/{code}`, `/metrics`, and `/demo/hit`, including `201`/`200`/`400`/`429` and `Retry-After`. It was inspected via the running service's Swagger UI at `http://localhost:8000/docs` and used to exercise `POST /shorten`.

| Endpoint | Method | Purpose | Important responses |
|---|---|---|---|
| `/shorten` | POST | Create a short link or return the existing code for a duplicate URL | `201`, `200`, `400`, `429` |
| `/{code}` | GET | Redirect to the destination associated with a short code | `307`, `404` |
| `/metrics` | GET | Expose Prometheus metrics | `200` |
| `/demo/hit` | GET | Generate a small demonstration metric | `200` |

Errors use a consistent JSON shape: `{"error": "..."}` (plus `retry_after` or `details` when relevant).

## 4. Before-and-after user task

**User task:** shorten a URL and safely repeat the request if the caller is unsure whether the first attempt succeeded.

| | Detail |
|---|---|
| Old endpoint | `POST /shorten` |
| Problem | Repeats could create confusion; excess traffic had no clear throttle; contract was undocumented |
| Change | Duplicate URL returns existing code (`200`); rate limit `5` / IP / `10s` with `429` + `Retry-After`; OpenAPI + `caller.py` |
| Reason | Retries become safe for the same URL; overload is explicit; callers know expected statuses |

| Endpoint | Changed or left alone |
|---|---|
| `POST /shorten` | Changed (idempotency, rate limit, clearer statuses) |
| `GET /{code}` | Left alone functionally (still `307`/`404`) |
| `GET /metrics` | Left for observability (excluded from “apply practices” review per brief) |
| `GET /demo/hit` | Left as a demo metric helper |

Callers updated: `caller.py` (timeout, retries, circuit breaker) and `grpc_client.py` for the gRPC path.

## 5. Rate limiting and idempotency

**Idempotency:** repeating the same URL returns the existing short code (`created=false`, HTTP `200`). New URLs return `201`. The optional `request_id` is for log correlation only, not a general idempotency-key store.

**Rate limit:** five accepted requests per client IP in a rolling ten-second window on `POST /shorten`. Over-limit requests get HTTP `429`, JSON `{"error":"rate limit exceeded","retry_after":N}`, and `Retry-After`. Clients behind the same IP share the limit. The in-memory limiter is process-local (fine for a single instance). Calls are allowed again when the oldest event in the window ages out (up to ~10 seconds).

## 6. Caller reliability demonstration

`caller.py` settings:

| Setting | Value |
|---|---|
| Timeout | 2 seconds |
| Max retries | 3 attempts |
| Backoff | 0.5 s, then 1.0 s (exponential) |
| Circuit open after | 3 failed operations |
| Recovery wait | 10 s (2 s in `--demo`) |

Retries apply to connection/server failures only (safe because shorten is idempotent on URL). HTTP `429` is not auto-retried by the caller.

Simulated run (`python .\caller.py --demo`):

1. Three operations each fail with connection errors and retry with backoff.
2. After three failed operations, the circuit opens.
3. A further request is blocked while open.
4. After the recovery wait, a successful request closes the circuit.

## 7. Automated tests

```powershell
python -m unittest -v test_app
```

Six tests: valid `201`, invalid `400`, duplicate URL `201` then `200` same code, sixth request `429` + `Retry-After`, unknown code `404`, `/metrics` contains `links_created_total`.

## 8. REST and gRPC call paths

```mermaid
flowchart LR
    subgraph HTTP
      HC[REST client / caller.py] --> HF[FastAPI app.py]
      HF --> LS[link_service.py]
    end
    subgraph gRPC
      GC[grpc_client.py] --> STUB[Generated LinkServiceStub]
      STUB --> GS[grpc_server LinkService handler]
      GS --> LS
    end
    LS --> DB[(SQLite links.db)]
    HF --> HM[/metrics :8000]
    GS --> GM[metrics :9095]
    HM --> P[Prometheus]
    GM --> P
    P --> G[Grafana]
```

Both interfaces use the same validation rules and SQLite source of truth. gRPC is not a wrapper around HTTP. Structured JSON logs include `request_id` on both paths for correlation.

**Status mapping examples**

| Case | HTTP | gRPC |
|---|---|---|
| New link | `201` + `created: true` | `OK` + `created: true` |
| Duplicate URL | `200` + `created: false` | `OK` + `created: false` |
| Invalid URL | `400` | `INVALID_ARGUMENT` |
| Rate limited | `429` + `Retry-After` | (HTTP only) |

## 9. gRPC

- Contract: `link.proto` — unary `CreateShortLink`
- Generate: `python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. link.proto`
- Server: `grpc_server.py` on `:50051`, metrics on `:9095`
- Client: `grpc_client.py` sets a deadline (`timeout=5` / `15`) and prints success or `RpcError`

## 10. Metrics audit (Part C)

| Useful from A1 | Gap | Fix |
|---|---|---|
| Link create / store gauges | HTTP responses not counted by status | `http_requests_total{method,endpoint,status}` |
| Duration histogram | Need gRPC latency too | `grpc_request_duration_seconds` |
| Rate-limit counter | Need gRPC call/error rates | `grpc_requests_total{method,status}` |
| — | Need concurrency signal | Chose **in-flight gauges** (`requests_in_progress`, `grpc_in_flight`) over message size because payloads are tiny and concurrency better shows load |

Duration is measured on the **server** (middleware / RPC handler), not in the Python caller. Labels are bounded (route templates, status codes, RPC names)—never user, request, or trace IDs as labels.

| Metric | Type | Unit | Labels | Location | Example query |
|---|---|---|---|---|---|
| `http_requests_total` | Counter | requests | method, endpoint, status | `app.py` middleware | `sum by (endpoint,status) (rate(http_requests_total[5m]))` |
| `http_request_duration_seconds` | Histogram | seconds | endpoint | `app.py` | `histogram_quantile(0.95, sum by (le,endpoint) (rate(http_request_duration_seconds_bucket[5m])))` |
| `requests_in_progress` | Gauge | requests | — | `app.py` | `requests_in_progress` |
| `http_rate_limited_total` | Counter | requests | — | `app.py` | `rate(http_rate_limited_total[5m])` |
| `grpc_requests_total` | Counter | requests | method, status | `grpc_server.py` | `sum by (method,status) (rate(grpc_requests_total[5m]))` |
| `grpc_request_duration_seconds` | Histogram | seconds | method | `grpc_server.py` | `histogram_quantile(0.95, sum by (le,method) (rate(grpc_request_duration_seconds_bucket[5m])))` |
| `grpc_in_flight` | Gauge | requests | — | `grpc_server.py` | `grpc_in_flight` |

Time window used on the dashboard: **5 minutes** for `rate()` / quantile estimates.

## 11. Dashboard

`grafana-dashboard.json` — ten panels: HTTP/gRPC request rates, error rates, p50/p95 latency, and in-flight gauges side by side. Datasource UID `prometheus` → `http://prometheus:9090`.

## 12. Reproducibility

See `README.md`. Generate success and failure traffic on both HTTP and gRPC before capturing Grafana screenshots. Confirm Prometheus targets are UP.

## 13. Conclusion

The project meets Part A (OpenAPI, idempotency, rate limit, reliability caller), Part B (shared-rules gRPC + client + statuses + call paths + correlated logs), and Part C (scraped gRPC metrics, Grafana panels, documented queries with bounded labels).
