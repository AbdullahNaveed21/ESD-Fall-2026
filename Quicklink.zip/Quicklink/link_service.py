﻿import os
import random
import sqlite3
import string
import time
from contextlib import contextmanager
from urllib.parse import urlsplit

DB_PATH = os.getenv("DB_PATH", "links.db")


@contextmanager
def get_db():
    """Open a database connection and always close it after use."""
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS links (
                code TEXT PRIMARY KEY,
                url TEXT UNIQUE NOT NULL,
                created_at REAL NOT NULL
            )
        """)
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def is_valid_url(url):
    """Accept only well-formed HTTP and HTTPS URLs."""
    if not isinstance(url, str):
        return False

    try:
        parsed = urlsplit(url.strip())
        return (
            parsed.scheme.lower() in ("http", "https")
            and bool(parsed.hostname)
            and parsed.port != 0
        )
    except (ValueError, AttributeError):
        return False


def gen_code():
    return "".join(
        random.choices(string.ascii_letters + string.digits, k=6)
    )


def create_link(url):
    """Create a short link, or return the existing code for a duplicate URL."""
    if not is_valid_url(url):
        raise ValueError("URL must be a valid HTTP or HTTPS URL")

    with get_db() as db:
        row = db.execute(
            "SELECT code FROM links WHERE url = ?", (url,)
        ).fetchone()

        if row:
            return row[0], False

        for _ in range(10):
            code = gen_code()
            try:
                db.execute(
                    "INSERT INTO links (code, url, created_at) VALUES (?, ?, ?)",
                    (code, url, time.time()),
                )
                return code, True
            except sqlite3.IntegrityError:
                row = db.execute(
                    "SELECT code FROM links WHERE url = ?", (url,)
                ).fetchone()
                if row:
                    return row[0], False

        raise RuntimeError("Could not generate a unique short code")


def resolve_link(code):
    with get_db() as db:
        row = db.execute(
            "SELECT url FROM links WHERE code = ?", (code,)
        ).fetchone()
        return row[0] if row else None


def count_links():
    with get_db() as db:
        return db.execute("SELECT COUNT(*) FROM links").fetchone()[0]
