
import argparse
import sys

import grpc

import link_pb2
import link_pb2_grpc


def create(stub, url, request_id, timeout):
    """Call CreateShortLink with a deadline and print success or error."""
    try:
        response = stub.CreateShortLink(
            link_pb2.CreateShortLinkRequest(
                url=url,
                request_id=request_id,
            ),
            timeout=timeout,
        )
        print(f"Success: code={response.code}, created={response.created}")
        return True
    except grpc.RpcError as exc:
        print(f"Error: {exc.code().name}: {exc.details()}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="QuickLink gRPC client (calls LinkService directly)"
    )
    parser.add_argument(
        "url",
        nargs="?",
        help="URL to shorten (omit to run the built-in success+failure demo)",
    )
    parser.add_argument(
        "--request-id",
        default="grpc-client",
        help="Optional request_id for log correlation",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=5.0,
        help="RPC deadline in seconds (default: 5)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1:50051",
        help="gRPC server address",
    )
    args = parser.parse_args()

    with grpc.insecure_channel(args.host) as channel:
        stub = link_pb2_grpc.LinkServiceStub(channel)

        if args.url:
            ok = create(stub, args.url, args.request_id, args.timeout)
            sys.exit(0 if ok else 1)

        print("Creating a short link...")
        create(
            stub,
            "https://example.com/grpc-demo",
            "grpc-demo-001",
            args.timeout,
        )

        print("\nTesting invalid URL...")
        create(stub, "not-a-url", "grpc-invalid-001", max(args.timeout, 15.0))


if __name__ == "__main__":
    main()
