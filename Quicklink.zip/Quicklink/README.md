﻿# QuickLink — Assignment 2

## Overview

QuickLink provides a REST API and a gRPC service for shortening URLs. Assignment 2 adds API documentation, duplicate-URL idempotency, rate limiting, a retrying caller with a circuit breaker demonstration, automated tests, and Prometheus/Grafana observability.

## Requirements

- Python 3.11 recommended for the Docker image
- Docker Desktop with Docker Compose
- Python dependencies in `requirements.txt`

## Start services

Run from the project directory:

```powershell
docker compose up -d --build app grpc prometheus grafana
```

Check status:

```powershell
docker compose ps
```

- REST API: `http://localhost:8000`
- Interactive API documentation: `http://localhost:8000/docs`
- Prometheus: `http://localhost:9090`
- Grafana: `http://localhost:3000`

Grafana's Prometheus datasource is configured in `grafana-datasource.yml`. Import `grafana-dashboard.json` through Grafana's dashboard import screen if the dashboard is not already installed. Initial Grafana credentials depend on the instance's existing configuration.

## REST tests

Install dependencies if required:

```powershell
python -m pip install -r requirements.txt
```

`httpx` is required for FastAPI’s `TestClient`.

Run tests:

```powershell
python -m unittest -v test_app
```

Or inside the running app container:

```powershell
docker compose exec app python -m unittest -v test_app
```

The tests cover valid creation, invalid URLs, duplicate URL behavior, rate limiting, unknown short codes, and the metrics endpoint.

## REST API examples

Create a short link:

```powershell
Invoke-RestMethod -Method Post `
  -Uri http://localhost:8000/shorten `
  -ContentType 'application/json' `
  -Body '{"url":"https://example.com"}'
```

Repeat the same request to check duplicate-URL behavior. The existing short code should be returned.

Inspect Prometheus metrics:

```powershell
Invoke-WebRequest http://localhost:8000/metrics
```

The rate limit allows five accepted requests per client IP in a rolling ten-second window. Excess requests receive HTTP 429 and a `Retry-After` header. Clients behind the same IP share the limit within the running API process. The header indicates how long to wait before retrying.

The REST contract is documented in `openapi.yaml`.

## gRPC

The protobuf contract is `link.proto`. The generated client/server modules are `link_pb2.py` and `link_pb2_grpc.py`.

Regenerate these files after changing the protobuf contract:

```powershell
python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. link.proto
```

With the service running:

```powershell
python .\grpc_client.py
```

The client demonstrates a successful request and an invalid-URL error. The gRPC server listens on port 50051 and exposes Prometheus metrics on port 9095.

## Caller reliability demonstration

Run the simulated failure/recovery demonstration:

```powershell
python .\caller.py --demo
```

This demo uses simulated responses and does not require a server. It demonstrates request timeouts, bounded retries with exponential backoff, a circuit breaker opening after repeated failed operations, blocking while open, and a recovery attempt.

Run the caller against the real REST API:

```powershell
python .\caller.py
```

The caller uses a timeout and retries connection/server failures. It does not automatically retry HTTP 429 responses.

## Monitoring

- Prometheus scrape configuration: `prometheus.yml`
- Grafana datasource: `grafana-datasource.yml`
- Dashboard export: `grafana-dashboard.json`

The dashboard includes HTTP and gRPC request rates, error responses, p50/p95 latency, and in-flight requests. Histogram quantiles are estimated from bucketed observations over a five-minute rate window. Generate both successful and failing REST/gRPC requests to populate the panels. Verify Prometheus targets before relying on the dashboard.

Metric labels use bounded endpoint templates, status codes, and gRPC method/status values. Do not add full URLs, request IDs, or short codes as metric labels because that can cause unbounded cardinality.

## Submission files

Include the application and service source, protobuf contract and generated modules, client scripts, tests, OpenAPI specification, Prometheus configuration, Grafana datasource/dashboard, Docker files, README, and `report.md`.

Do not include the SQLite database, Docker volumes, virtual environments, caches, or credentials in the submission archive.
