﻿import os
import tempfile
import unittest

from fastapi.testclient import TestClient

import app
import link_service


class QuickLinkAPITests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.original_db_path = link_service.DB_PATH
        link_service.DB_PATH = os.path.join(self.temp_dir.name, "test.db")

        app.request_times.clear()
        app.cache.clear()
        self.client = TestClient(app.app)

    def tearDown(self):
        link_service.DB_PATH = self.original_db_path
        self.temp_dir.cleanup()

    def test_valid_url_creates_link(self):
        response = self.client.post(
            "/shorten",
            json={"url": "https://example.com/test-valid"},
        )
        self.assertEqual(response.status_code, 201)
        body = response.json()
        self.assertTrue(body["created"])
        self.assertTrue(body["code"])

    def test_invalid_url_returns_400(self):
        response = self.client.post(
            "/shorten",
            json={"url": "not-a-valid-url"},
        )
        self.assertEqual(response.status_code, 400)
        self.assertIn("error", response.json())

    def test_repeated_url_is_idempotent(self):
        url = "https://example.com/test-idempotency"
        first = self.client.post("/shorten", json={"url": url})
        second = self.client.post("/shorten", json={"url": url})

        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(first.json()["code"], second.json()["code"])
        self.assertFalse(second.json()["created"])

    def test_rate_limit_returns_429_and_retry_after(self):
        url = "https://example.com/test-rate-limit"

        responses = [
            self.client.post("/shorten", json={"url": url})
            for _ in range(6)
        ]

        self.assertTrue(all(r.status_code in (200, 201) for r in responses[:5]))
        self.assertEqual(responses[5].status_code, 429)
        self.assertIn("Retry-After", responses[5].headers)
        self.assertGreaterEqual(int(responses[5].headers["Retry-After"]), 1)

    def test_unknown_code_returns_404(self):
        response = self.client.get("/definitely-unknown-code", follow_redirects=False)
        self.assertEqual(response.status_code, 404)

    def test_metrics_endpoint_returns_prometheus_text(self):
        response = self.client.get("/metrics")
        self.assertEqual(response.status_code, 200)
        self.assertIn("links_created_total", response.text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
