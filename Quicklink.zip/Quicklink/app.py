
import logging
import os
import time
import uuid
from collections import defaultdict, deque
from threading import Lock
from urllib.parse import urlsplit

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse, Response
from pydantic import BaseModel
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    Counter,
    Gauge,
    Histogram,
    Summary,
    generate_latest,
)

import link_service

app = FastAPI(title="QuickLink API", version="2.0.0")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("quicklink")

links_created_total = Counter(
    "links_created_total", "Total short links created through REST"
)
links_stored_gauge = Gauge(
    "links_stored_total", "Current number of links in the shared database"
)
requests_failed_total = Counter(
    "http_requests_failed_total", "Failed HTTP requests", ["endpoint"]
)
http_requests_total = Counter(
    "http_requests_total",
    "HTTP responses by endpoint and status code",
    ["method", "endpoint", "status"],
)
requests_in_progress = Gauge(
    "requests_in_progress", "HTTP requests currently being handled"
)
request_duration = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration",
    ["endpoint"],
    buckets=[0.01, 0.05, 0.1, 0.5, 1, 2, 5],
)
lookup_duration = Summary(
    "redirect_lookup_duration_seconds", "Time to resolve a short code"
)
http_rate_limited_total = Counter(
    "http_rate_limited_total", "HTTP requests rejected by rate limiting"
)
shorten_idempotent_hits_total = Counter(
    "shorten_idempotent_hits_total", "Repeated URL submissions"
)
demo_requests_total = Counter(
    "demo_requests_total", "Demo requests, with optional cardinality experiment",
    ["kind"],
)

RATE_LIMIT = 5
RATE_WINDOW_SECONDS = 10
rate_lock = Lock()
request_times = defaultdict(deque)
cache = {}
FAULT_INJECT = os.getenv("FAULT_INJECT", "0") == "1"


class ShortenRequest(BaseModel):
    url: str
    request_id: str | None = None


def log_json(severity, message, **fields):
    entry = {
        "time": time.time(),
        "service": "quicklink",
        "severity": severity,
        "message": message,
        **fields,
    }
    logger.log(
        logging.ERROR if severity == "ERROR" else logging.INFO,
        "%s", __import__("json").dumps(entry)
    )


def valid_url(url):
    try:
        parsed = urlsplit(url.strip())
        return (
            parsed.scheme.lower() in ("http", "https")
            and bool(parsed.hostname)
            and parsed.port != 0
        )
    except (ValueError, AttributeError):
        return False


def endpoint_label(request):
    # Use FastAPI route templates, never raw dynamic URL paths.
    route = request.scope.get("route")
    return getattr(route, "path", "unmatched")


def rate_limit_exceeded(client_key):
    now = time.monotonic()
    with rate_lock:
        events = request_times[client_key]
        while events and now - events[0] >= RATE_WINDOW_SECONDS:
            events.popleft()

        if len(events) >= RATE_LIMIT:
            retry_after = max(
                1, int(RATE_WINDOW_SECONDS - (now - events[0]) + 0.999)
            )
            return retry_after

        events.append(now)
        return None


@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    request_id = str(uuid.uuid4())
    start = time.monotonic()
    requests_in_progress.inc()
    response = None

    try:
        response = await call_next(request)
        return response
    except Exception as exc:
        requests_failed_total.labels(endpoint_label(request)).inc()
        log_json(
            "ERROR", "request failed",
            request_id=request_id,
            endpoint=endpoint_label(request),
            error=str(exc),
        )
        raise
    finally:
        duration = time.monotonic() - start
        status_code = response.status_code if response else 500
        request_duration.labels(endpoint_label(request)).observe(duration)
        http_requests_total.labels(
            method=request.method,
            endpoint=endpoint_label(request),
            status=str(status_code),
        ).inc()
        requests_in_progress.dec()
        log_json(
            "INFO", "request handled",
            request_id=request_id,
            endpoint=endpoint_label(request),
            status=status_code,
            duration=duration,
        )


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=400,
        content={"error": "invalid request", "details": exc.errors()},
    )


@app.post("/shorten")
def shorten(payload: ShortenRequest, request: Request):
    client_key = request.client.host if request.client else "unknown"
    retry_after = rate_limit_exceeded(client_key)

    if retry_after is not None:
        http_rate_limited_total.inc()
        return JSONResponse(
            status_code=429,
            content={"error": "rate limit exceeded", "retry_after": retry_after},
            headers={"Retry-After": str(retry_after)},
        )

    url = payload.url.strip()
    if not valid_url(url):
        return JSONResponse(
            status_code=400,
            content={"error": "URL must be a valid HTTP or HTTPS URL"},
        )

    try:
        code, created = link_service.create_link(url)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={"error": str(exc)})

    if created:
        links_created_total.inc()
        log_json(
            "INFO", "link created",
            request_id=payload.request_id,
            code=code,
        )
        status_code = 201
    else:
        shorten_idempotent_hits_total.inc()
        status_code = 200

    cache[code] = url

    return JSONResponse(
        status_code=status_code,
        content={"code": code, "created": created},
    )


@app.get("/metrics")
def metrics():
    # Refresh from SQLite so links created by gRPC are counted too.
    links_stored_gauge.set(link_service.count_links())
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.get("/demo/hit")
def demo_hit():
    demo_requests_total.labels(kind="normal").inc()
    return {"ok": True}


@app.get("/{code}")
def redirect(code: str):
    start = time.monotonic()

    if FAULT_INJECT:
        time.sleep(0.5)

    if code in cache:
        url = cache[code]
    else:
        url = link_service.resolve_link(code)
        if url is None:
            requests_failed_total.labels("/\u007bcode\u007d").inc()
            log_json("WARN", "link not found", code=code)
            return JSONResponse({"error": "not found"}, status_code=404)
        cache[code] = url

    lookup_duration.observe(time.monotonic() - start)
    return RedirectResponse(url, status_code=307)
