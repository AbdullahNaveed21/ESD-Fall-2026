"""Counts Envoy access-log events per replica in Elasticsearch (for the log cross-check).
  python count_envoy.py http 10     # interface, minutes back
"""
import json
import sys
import urllib.request

interface = sys.argv[1] if len(sys.argv) > 1 else "http"
minutes = sys.argv[2] if len(sys.argv) > 2 else "10"


def ask(field):
    body = {
        "size": 0,
        "query": {"bool": {"filter": [
            {"term": {"ql.service": "envoy"}},
            {"term": {"ql.interface": interface}},
            {"range": {"@timestamp": {"gte": f"now-{minutes}m"}}},
        ]}},
        "aggs": {"by_replica": {"terms": {"field": field, "size": 10, "missing": "none"}}},
    }
    req = urllib.request.Request(
        "http://localhost:9200/quicklink-*/_search",
        data=json.dumps(body).encode(), headers={"Content-Type": "application/json"},
    )
    return json.load(urllib.request.urlopen(req))


try:
    res = ask("ql.selected_replica")
except Exception:
    res = ask("ql.selected_replica.keyword")

buckets = res["aggregations"]["by_replica"]["buckets"]
total = sum(b["doc_count"] for b in buckets)
print(f"Envoy {interface} events in the last {minutes} min: {total}")
for b in buckets:
    print(f"  replica {b['key']}: {b['doc_count']}  ({100 * b['doc_count'] / total:.1f}%)")
