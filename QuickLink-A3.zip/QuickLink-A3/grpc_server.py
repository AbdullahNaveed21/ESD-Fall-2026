
import json
import logging
import os
import time
import uuid
from concurrent import futures

import grpc
from grpc_health.v1 import health, health_pb2_grpc
from prometheus_client import Counter, Gauge, Histogram, start_http_server

import link_pb2
import link_pb2_grpc
import link_service

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger("quicklink-grpc")

REPLICA_ID = os.getenv("REPLICA_ID", "A")
FAULT_DELAY_MS = int(os.getenv("FAULT_DELAY_MS", "0"))

replica_info = Gauge("quicklink_replica_info", "Which replica this is", ["replica"])
replica_info.labels(REPLICA_ID).set(1)

grpc_requests_total = Counter(
    "grpc_requests_total",
    "Total gRPC requests",
    ["method", "status"],
)
grpc_request_duration = Histogram(
    "grpc_request_duration_seconds",
    "gRPC request duration",
    ["method"],
    buckets=[0.005, 0.01, 0.025, 0.05, 0.1, 0.2, 0.3, 0.5, 1, 2, 5],
)
grpc_in_flight = Gauge(
    "grpc_in_flight",
    "gRPC requests currently being handled",
)


def log_json(severity, message, **fields):
    """Structured JSON logs with request_id for A1-style correlation."""
    entry = {
        "time": time.time(),
        "service": "quicklink-grpc",
        "replica": REPLICA_ID,
        "interface": "grpc",
        "severity": severity,
        "message": message,
        **fields,
    }
    logger.log(
        logging.ERROR if severity == "ERROR" else logging.INFO,
        "%s",
        json.dumps(entry),
    )


class LinkService(link_pb2_grpc.LinkServiceServicer):

    def CreateShortLink(self, request, context):
        method = "CreateShortLink"
        start = time.monotonic()
        grpc_in_flight.inc()
        status = "OK"
        # Prefer client-supplied request_id so logs correlate across HTTP/gRPC.
        # Envoy forwards the x-request-id header as gRPC metadata.
        md = dict(context.invocation_metadata())
        request_id = (
            md.get("x-request-id")
            or (request.request_id or "").strip()
            or str(uuid.uuid4())
        )
        context.set_trailing_metadata((("x-replica", REPLICA_ID),))

        try:
            if FAULT_DELAY_MS:
                time.sleep(FAULT_DELAY_MS / 1000)

            if not link_service.is_valid_url(request.url):
                status = "INVALID_ARGUMENT"
                context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
                context.set_details(
                    "URL must be a valid HTTP or HTTPS URL"
                )
                log_json(
                    "WARN",
                    "invalid url",
                    request_id=request_id,
                    method=method,
                    status=status,
                )
                return link_pb2.CreateShortLinkReply()

            code, created = link_service.create_link(request.url)
            log_json(
                "INFO",
                "link created" if created else "idempotent hit",
                request_id=request_id,
                method=method,
                code=code,
                created=created,
            )
            return link_pb2.CreateShortLinkReply(
                code=code,
                created=created,
            )

        except ValueError as exc:
            status = "INVALID_ARGUMENT"
            context.set_code(grpc.StatusCode.INVALID_ARGUMENT)
            context.set_details(str(exc))
            log_json(
                "WARN",
                "validation failed",
                request_id=request_id,
                method=method,
                error=str(exc),
            )
            return link_pb2.CreateShortLinkReply()

        except Exception as exc:
            status = "INTERNAL"
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details("Unable to create short link")
            log_json(
                "ERROR",
                "create failed",
                request_id=request_id,
                method=method,
                error=str(exc),
            )
            return link_pb2.CreateShortLinkReply()

        finally:
            duration = time.monotonic() - start
            grpc_requests_total.labels(
                method=method, status=status
            ).inc()
            grpc_request_duration.labels(method=method).observe(duration)
            grpc_in_flight.dec()
            log_json(
                "INFO",
                "rpc handled",
                request_id=request_id,
                method=method,
                status=status,
                duration=duration,
            )


def serve():
    metrics_port = int(os.getenv("GRPC_METRICS_PORT", "9095"))
    grpc_port = int(os.getenv("GRPC_PORT", "50051"))

    start_http_server(metrics_port)

    server = grpc.server(futures.ThreadPoolExecutor(max_workers=50))
    link_pb2_grpc.add_LinkServiceServicer_to_server(LinkService(), server)
    # standard gRPC health service, used by Envoy's active health check
    health_pb2_grpc.add_HealthServicer_to_server(health.HealthServicer(), server)
    server.add_insecure_port(f"[::]:{grpc_port}")

    print(f"gRPC server listening on port {grpc_port}")
    print(f"gRPC Prometheus metrics listening on port {metrics_port}")

    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    serve()
