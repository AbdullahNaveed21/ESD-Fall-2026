"""Fixed-rate, non-blocking load generator for QuickLink (HTTP or gRPC).

Examples
  python loadgen.py --mode http --rate 30 --duration 60
  python loadgen.py --mode grpc --rate 30 --duration 60

It sends one request every 1/rate seconds on a fixed schedule. It never waits
for a reply before sending the next one, so a slow server cannot slow the rate down.
"""
import argparse
import asyncio
import json
import time
import uuid
from collections import Counter

import grpc
import httpx

import link_pb2
import link_pb2_grpc


def pct(values, p):
    if not values:
        return 0.0
    values = sorted(values)
    return values[min(len(values) - 1, int(round(p / 100 * (len(values) - 1))))]


async def http_call(client, base, code):
    rid = str(uuid.uuid4())
    t0 = time.perf_counter()
    try:
        r = await client.get(f"{base}/{code}", headers={"x-request-id": rid})
        ok = r.status_code < 400            # 307 redirect = success
        return ok, str(r.status_code), r.headers.get("x-replica", "?"), time.perf_counter() - t0
    except Exception as exc:
        return False, type(exc).__name__, "?", time.perf_counter() - t0


async def grpc_call(stub, url):
    rid = str(uuid.uuid4())
    t0 = time.perf_counter()
    call = stub.CreateShortLink(
        link_pb2.CreateShortLinkRequest(url=url), metadata=(("x-request-id", rid),), timeout=5
    )
    try:
        await call
        status, ok = "OK", True
    except grpc.aio.AioRpcError as exc:
        status, ok = exc.code().name, False
    replica = "?"
    try:
        for k, v in (await call.trailing_metadata() or []):
            if k == "x-replica":
                replica = v
    except Exception:
        pass
    return ok, status, replica, time.perf_counter() - t0


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["http", "grpc"], required=True)
    ap.add_argument("--rate", type=float, default=30, help="target requests per second")
    ap.add_argument("--duration", type=float, default=60, help="seconds")
    ap.add_argument("--http-base", default="http://localhost:10000")
    ap.add_argument("--grpc-target", default="localhost:10001")
    ap.add_argument("--url", default="https://example.com/loadtest")
    ap.add_argument("--label", default="")
    args = ap.parse_args()

    total = int(args.rate * args.duration)
    interval = 1.0 / args.rate

    if args.mode == "http":
        client = httpx.AsyncClient(
            timeout=5, follow_redirects=False,
            limits=httpx.Limits(max_connections=500, max_keepalive_connections=200),
        )
        # make one short link first so GET /{code} has something to redirect to
        r = await client.post(f"{args.http_base}/shorten", json={"url": args.url})
        code = r.json()["code"]
        print(f"using short code {code}")
        fire = lambda: http_call(client, args.http_base, code)
    else:
        channel = grpc.aio.insecure_channel(args.grpc_target)   # ONE channel on purpose
        stub = link_pb2_grpc.LinkServiceStub(channel)
        fire = lambda: grpc_call(stub, args.url)

    print(f"{args.mode}: {args.rate} rps for {args.duration}s ({total} requests)")
    start = time.perf_counter()
    tasks, max_lag = [], 0.0
    for i in range(total):
        wait = start + i * interval - time.perf_counter()
        if wait > 0:
            await asyncio.sleep(wait)
        else:
            max_lag = max(max_lag, -wait)
        tasks.append(asyncio.create_task(fire()))   # fire and move on
    send_time = time.perf_counter() - start
    results = await asyncio.gather(*tasks)

    ok_lat = [r[3] for r in results if r[0]]
    all_lat = [r[3] for r in results]
    by_replica = Counter(r[2] for r in results if r[0])
    by_status = Counter(r[1] for r in results)
    failed = sum(1 for r in results if not r[0])
    summary = {
        "label": args.label, "mode": args.mode,
        "target_rps": args.rate, "actual_send_rps": round(total / send_time, 2),
        "sent": total, "success": total - failed, "failed": failed,
        "error_rate_pct": round(100 * failed / total, 2),
        "client_p50_ms": round(pct(ok_lat, 50) * 1000, 1),
        "client_p95_ms": round(pct(ok_lat, 95) * 1000, 1),
        "client_p95_all_ms": round(pct(all_lat, 95) * 1000, 1),
        "max_schedule_lag_ms": round(max_lag * 1000, 1),
        "replica_share_pct": {k: round(100 * v / max(1, sum(by_replica.values())), 1)
                              for k, v in sorted(by_replica.items())},
        "status_counts": dict(by_status),
    }
    print(json.dumps(summary, indent=2))
    if args.mode == "http":
        await client.aclose()
    else:
        await channel.close()


asyncio.run(main())
