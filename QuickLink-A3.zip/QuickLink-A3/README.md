# QuickLink A3 - Envoy load balancing

Setup (PowerShell, inside this folder)
    pip install httpx grpcio grpcio-tools protobuf
    python make_envoy.py a        # Part A: Envoy sends everything to replica A
    docker compose up -d --build

Modes (regenerate envoy.yaml, then restart only Envoy)
    python make_envoy.py rr       # equal round robin (Part C)
    python make_envoy.py wrr      # weighted 2:1:1
    python make_envoy.py lr       # least request
    docker compose restart envoy

Load test
    python loadgen.py --mode http --rate 30 --duration 60 --label baseline-http
    python loadgen.py --mode grpc --rate 30 --duration 60 --label baseline-grpc

Delay on B (least request experiment)
    $env:DELAY_B="200"; docker compose up -d app-b grpc-b
    $env:DELAY_B="0";   docker compose up -d app-b grpc-b

Failure and recovery
    docker compose stop app-b grpc-b
    docker compose start app-b grpc-b

Log check
    python count_envoy.py http 10
    python count_envoy.py grpc 10

UIs: Grafana :3000 (admin/admin), Prometheus :9090, Kibana :5601, Envoy admin :9901
